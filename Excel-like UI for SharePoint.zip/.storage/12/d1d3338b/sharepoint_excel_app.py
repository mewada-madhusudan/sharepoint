from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import json
import os
from datetime import datetime
import requests
from requests.auth import HTTPBasicAuth
import base64

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this in production
CORS(app)

class SharePointConnector:
    def __init__(self, site_url, username, password):
        self.site_url = site_url
        self.username = username
        self.password = password
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(username, password)
        self.headers = {
            'Accept': 'application/json;odata=verbose',
            'Content-Type': 'application/json;odata=verbose',
        }
    
    def get_request_digest(self):
        """Get request digest for POST operations"""
        url = f"{self.site_url}/_api/contextinfo"
        response = self.session.post(url, headers=self.headers)
        if response.status_code == 200:
            data = response.json()
            return data['d']['GetContextWebInformation']['FormDigestValue']
        return None
    
    def get_list_items(self, list_name, select_fields=None, filter_query=None, top=1000):
        """Fetch items from SharePoint list"""
        url = f"{self.site_url}/_api/web/lists/getbytitle('{list_name}')/items"
        
        params = {'$top': top}
        if select_fields:
            params['$select'] = ','.join(select_fields)
        if filter_query:
            params['$filter'] = filter_query
            
        response = self.session.get(url, headers=self.headers, params=params)
        
        if response.status_code == 200:
            return response.json()['d']['results']
        else:
            raise Exception(f"Failed to fetch data: {response.status_code}")
    
    def get_list_fields(self, list_name):
        """Get list field definitions"""
        url = f"{self.site_url}/_api/web/lists/getbytitle('{list_name}')/fields"
        params = {'$filter': "Hidden eq false and ReadOnlyField eq false"}
        
        response = self.session.get(url, headers=self.headers, params=params)
        
        if response.status_code == 200:
            fields = response.json()['d']['results']
            return [{'name': f['InternalName'], 'title': f['Title'], 'type': f['TypeAsString']} 
                   for f in fields if f['InternalName'] not in ['ContentType', 'Attachments']]
        return []
    
    def update_item(self, list_name, item_id, data):
        """Update a SharePoint list item"""
        digest = self.get_request_digest()
        if not digest:
            raise Exception("Failed to get request digest")
        
        url = f"{self.site_url}/_api/web/lists/getbytitle('{list_name}')/items({item_id})"
        
        headers = self.headers.copy()
        headers.update({
            'X-RequestDigest': digest,
            'X-HTTP-Method': 'MERGE',
            'If-Match': '*'
        })
        
        # Prepare data for SharePoint
        update_data = {'__metadata': {'type': f'SP.Data.{list_name}ListItem'}}
        update_data.update(data)
        
        response = self.session.post(url, headers=headers, json=update_data)
        return response.status_code == 204
    
    def create_item(self, list_name, data):
        """Create a new SharePoint list item"""
        digest = self.get_request_digest()
        if not digest:
            raise Exception("Failed to get request digest")
        
        url = f"{self.site_url}/_api/web/lists/getbytitle('{list_name}')/items"
        
        headers = self.headers.copy()
        headers['X-RequestDigest'] = digest
        
        # Prepare data for SharePoint
        create_data = {'__metadata': {'type': f'SP.Data.{list_name}ListItem'}}
        create_data.update(data)
        
        response = self.session.post(url, headers=headers, json=create_data)
        if response.status_code == 201:
            return response.json()['d']
        return None
    
    def delete_item(self, list_name, item_id):
        """Delete a SharePoint list item"""
        digest = self.get_request_digest()
        if not digest:
            raise Exception("Failed to get request digest")
        
        url = f"{self.site_url}/_api/web/lists/getbytitle('{list_name}')/items({item_id})"
        
        headers = self.headers.copy()
        headers.update({
            'X-RequestDigest': digest,
            'X-HTTP-Method': 'DELETE',
            'If-Match': '*'
        })
        
        response = self.session.post(url, headers=headers)
        return response.status_code == 200

# Global SharePoint connector (in production, use proper session management)
sharepoint = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/connect', methods=['POST'])
def connect_sharepoint():
    global sharepoint
    data = request.json
    
    try:
        sharepoint = SharePointConnector(
            data['site_url'],
            data['username'],
            data['password']
        )
        
        # Test connection by getting a simple request
        sharepoint.get_request_digest()
        
        session['connected'] = True
        session['site_url'] = data['site_url']
        
        return jsonify({'success': True, 'message': 'Connected successfully'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/lists/<list_name>/fields')
def get_list_fields(list_name):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    try:
        fields = sharepoint.get_list_fields(list_name)
        return jsonify(fields)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/lists/<list_name>/items')
def get_list_items(list_name):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    # Get query parameters
    select_fields = request.args.get('select')
    filter_query = request.args.get('filter')
    top = int(request.args.get('top', 1000))
    
    try:
        select_list = select_fields.split(',') if select_fields else None
        items = sharepoint.get_list_items(list_name, select_list, filter_query, top)
        return jsonify(items)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/lists/<list_name>/items/<int:item_id>', methods=['PUT'])
def update_item(list_name, item_id):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    data = request.json
    
    try:
        success = sharepoint.update_item(list_name, item_id, data)
        if success:
            return jsonify({'success': True, 'message': 'Item updated successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to update item'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/lists/<list_name>/items', methods=['POST'])
def create_item(list_name):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    data = request.json
    
    try:
        new_item = sharepoint.create_item(list_name, data)
        if new_item:
            return jsonify({'success': True, 'item': new_item})
        else:
            return jsonify({'success': False, 'message': 'Failed to create item'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/lists/<list_name>/items/<int:item_id>', methods=['DELETE'])
def delete_item(list_name, item_id):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    try:
        success = sharepoint.delete_item(list_name, item_id)
        if success:
            return jsonify({'success': True, 'message': 'Item deleted successfully'})
        else:
            return jsonify({'success': False, 'message': 'Failed to delete item'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/export/<list_name>')
def export_data(list_name):
    if not sharepoint:
        return jsonify({'error': 'Not connected to SharePoint'}), 400
    
    try:
        items = sharepoint.get_list_items(list_name)
        
        # Convert to CSV format
        if items:
            import csv
            import io
            
            output = io.StringIO()
            writer = csv.DictWriter(output, fieldnames=items[0].keys())
            writer.writeheader()
            writer.writerows(items)
            
            csv_data = output.getvalue()
            
            return jsonify({
                'success': True,
                'data': csv_data,
                'filename': f'{list_name}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
            })
        else:
            return jsonify({'success': False, 'message': 'No data to export'})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)